def print_lol(the_list,level=0):
	for _list in the_list:
		if isinstance(_list,list):
			print_lol(_list,level + 1)
		else:
			for num_ in range(level):
				print('\t'),
			print(_list)
