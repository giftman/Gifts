from distutils.core import setup
setup(
		name = 'giftman_nester',
		version = '1.0.0',
		py_modules = ['giftman_nester'],
		author = 'giftman',
		author_email = '121552591@qq.com',
		url = 'www.baidu.com',
		description = 'A S',
     )
