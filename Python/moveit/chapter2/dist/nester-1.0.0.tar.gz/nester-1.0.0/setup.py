from distutils.core import setup
setup(
		name = 'nester',
		version = '1.0.0',
		py_modules = ['nester'],
		author = 'hfpython',
		author_email = '121552591@qq.com',
		url = 'www.baidu.com',
		description = 'A S',
     )
